#ifndef JOYSTICK_H
#define JOYSTICK_H

#include "pico/stdlib.h"
#include "hardware/adc.h" //Para usar o ADC


// Pinos joystick
#define JOYSTICK_X_PIN 26 // Pino de leitura do eixo X do joystick (conectado ao ADC)
#define JOYSTICK_Y_PIN 27 // Pino de leitura do eixo Y do joystick (conectado ao ADC)
#define JOYSTICK_SW_PIN 22 // Pino de leitura do botão do joystick
#define ADC_CHANNEL_0 0 // Canal ADC para o eixo Y do joystick
#define ADC_CHANNEL_1 1 // Canal ADC para o eixo X do joystick

// Limites do Joystick
#define JOYSTICK_THRESHOLD 1000

// Tempos (em milissegundos)
#define DEBOUNCE_DELAY 50

typedef enum {
    JOY_UP,
    JOY_DOWN,
    JOY_LEFT,
    JOY_RIGHT,
    JOY_CENTER,
    JOY_NONE // Nenhuma direção pressionada
} JoystickDirection;

void joystick_init();
JoystickDirection joystick_read();

#endif