#include "buzzer.h"

// Inicializa o PWM no pino do buzzer
void pwm_init_buzzer() {
    // Configuração do pino do buzzer como saída PWM
    gpio_set_function(BUZZER_PIN, GPIO_FUNC_PWM);
    uint slice_num = pwm_gpio_to_slice_num(BUZZER_PIN);
    pwm_config config = pwm_get_default_config();
    pwm_config_set_clkdiv(&config, 4.0f); // Ajusta divisor de clock
    pwm_init(slice_num, &config, true);
    pwm_set_gpio_level(BUZZER_PIN, 0); // Desliga o PWM inicialmente
}

// Toca uma nota com a frequência e duração especificadas
void buzzer_play_tone(uint frequency, uint duration_ms) {
    uint slice_num = pwm_gpio_to_slice_num(BUZZER_PIN);
    uint32_t clock_freq = clock_get_hz(clk_sys);
    uint32_t top = clock_freq / frequency - 1;

    pwm_set_wrap(slice_num, top);
    pwm_set_gpio_level(BUZZER_PIN, top / 2); // 50% de duty cycle

    sleep_ms(duration_ms);

    pwm_set_gpio_level(BUZZER_PIN, 0); // Desliga o som após a duração
    sleep_ms(50); // Pausa entre notas
}

void buzzer_stop() {
    // Desliga o buzzer
     uint slice_num = pwm_gpio_to_slice_num(BUZZER_PIN);
     pwm_set_enabled(slice_num, false);
}

void play_up(){
    buzzer_play_tone(NOTE_C4,NOTE_DURATION);
}

void play_down(){
    buzzer_play_tone(NOTE_E4,NOTE_DURATION);
}

void play_right(){
    buzzer_play_tone(NOTE_G4,NOTE_DURATION);
}

void play_left(){
    buzzer_play_tone(NOTE_B4,NOTE_DURATION);
}

void play_win(){
    buzzer_play_tone(NOTE_A4, 100);
    buzzer_play_tone(NOTE_C4, 150);
}

void play_game_over(){
    //buzzer_play_tone(NOTE_G4, 250);
/** 
    buzzer_play_tone(NOTE_C4 - 24, 200); // C2 (grave)
    sleep_ms(50);
    buzzer_play_tone(NOTE_C4 - 24, 200); // C2
    sleep_ms(50);
    buzzer_play_tone(NOTE_C4 - 24, 300); // C2 (mais longa)
    sleep_ms(400);
*/
// Sequência de notas para a melodia
    const uint notes[] = {NOTE_E4, NOTE_D4, NOTE_C4, NOTE_B4 - 12, NOTE_A4 - 12, NOTE_G4 - 24};

    // Duração de cada nota (em milissegundos)
    const uint durations[] = {200, 200, 200, 250, 250, 300};

    int num_notes = sizeof(notes) / sizeof(notes[0]);

    // Toca a melodia
    for (int i = 0; i < num_notes; ++i) {
        buzzer_play_tone(notes[i], durations[i]);
    }

    sleep_ms(400); // Pausa no final
}