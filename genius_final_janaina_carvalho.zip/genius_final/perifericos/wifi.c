#include "wifi.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Variáveis Globais (definidas aqui, declaradas como extern no .h)
struct tcp_pcb *tcp_client_pcb;
ip_addr_t server_ip;

// Buffer para armazenar a resposta da leitura
char read_buffer[1024];  
int read_buffer_len = 0;

bool record_read = false;

int read_value = -1;
bool read_complete = false; // Flag to indicate completion
bool write_complete = false; // Flag to indicate completion

extern int new_record;

// 📌 Callback para receber resposta do ThingSpeak
static err_t http_recv_callback(void *arg, struct tcp_pcb *tpcb, struct pbuf *p, err_t err) {
    if (p == NULL) {
        tcp_close(tpcb);
        write_complete = true;
        return ERR_OK;
    }
    printf("Resposta do ThingSpeak: %.*s\n", p->len, (char *)p->payload);
    pbuf_free(p);
    return ERR_OK;
}

// 📌 Callback para conexão TCP
static err_t http_connected_callback(void *arg, struct tcp_pcb *tpcb, err_t err) {
    if (err != ERR_OK) {
        printf("Erro na conexão TCP\n");
        return err;
    }

    printf("Conectado ao ThingSpeak!\n");

    char request[256];
    printf("\n\n!!!!!!!Sendo enviado: %d !!!!!!!!\n\n", new_record);
    snprintf(request, sizeof(request),
        "GET /update?api_key=%s&field1=%d HTTP/1.1\r\n"
        "Host: %s\r\n"
        "Connection: close\r\n"
        "\r\n",
        API_KEY, new_record, THINGSPEAK_HOST);

    tcp_write(tpcb, request, strlen(request), TCP_WRITE_FLAG_COPY);
    tcp_output(tpcb);
    tcp_recv(tpcb, http_recv_callback);

    return ERR_OK;
}

// 📌 Resolver DNS e conectar ao servidor
static void dns_callback(const char *name, const ip_addr_t *ipaddr, void *callback_arg) {
    if (ipaddr) {
        printf("Endereço IP do ThingSpeak: %s\n", ipaddr_ntoa(ipaddr));
        tcp_client_pcb = tcp_new();
        tcp_connect(tcp_client_pcb, ipaddr, THINGSPEAK_PORT, http_connected_callback);
    } else {
        printf("Falha na resolução de DNS\n");
    }
}


// 📌 Função para conectar ao Wi-Fi
int wifi_init(uint flag_wifi) {
    if(flag_wifi==0){
        if (cyw43_arch_init()) {
            printf("Falha ao iniciar Wi-Fi\n");
            return 1;
        }
    }

    cyw43_arch_enable_sta_mode();
    printf("Conectando ao Wi-Fi...\n");

    if (cyw43_arch_wifi_connect_blocking(WIFI_SSID, WIFI_PASS, CYW43_AUTH_WPA2_MIXED_PSK)) {
        printf("Falha ao conectar ao Wi-Fi\n");
        return 1;
    }

    printf("Wi-Fi conectado!\n");

    return 0;
}

// Função para enviar novo recorde ao ThingSpeak
bool send_new_record_to_thingspeak(){
    write_complete = false;
    dns_gethostbyname(THINGSPEAK_HOST, &server_ip, dns_callback, NULL);
    return true;
}

// Callback para leitura de dados do ThingSpeak
static err_t http_recv_read_callback(void *arg, struct tcp_pcb *tpcb, struct pbuf *p, err_t err) {
    if (p == NULL) {
        // Conexão fechada pelo servidor
        tcp_close(tpcb);
        tcp_client_pcb = NULL;

        if (read_buffer_len > 0) {
            char* data = read_buffer;

            // 1. Localiza o início do array "feeds"
            char* feeds_start = strstr(data, "\"feeds\":[");
            if (!feeds_start) {
                printf("Erro: \"feeds\" não encontrado.\n");
                *((int*)arg) = -1;
                read_complete = true;
                return ERR_OK;
            }

            // 2. Localiza o início do primeiro objeto dentro de "feeds"
            char* object_start = strchr(feeds_start + strlen("\"feeds\":["), '{');
            if (!object_start) {
                printf("Erro: Objeto não encontrado em \"feeds\".\n");
                *((int*)arg) = -1;
                read_complete = true;
                return ERR_OK;
            }

            // 3. Localiza "field1" dentro do objeto
            char* field1_start = strstr(object_start, "\"field1\":");
            if (!field1_start) {
                printf("Erro: \"field1\" não encontrado no objeto.\n");
                *((int*)arg) = -1;
                read_complete = true;
                return ERR_OK;
            }

            field1_start += strlen("\"field1\":\""); // Pula as aspas
            char* field1_end = strchr(field1_start, '"'); // Encontra a aspa de fechamento

            if (field1_end) {
                int field1_len = field1_end - field1_start;
                char field1_str[16]; // Ajuste o tamanho se necessário
                strncpy(field1_str, field1_start, field1_len);
                field1_str[field1_len] = '\0';
                *((int*)arg) = atoi(field1_str);
            } else {
                printf("Erro ao extrair valor de \"field1\".\n");
                *((int*)arg) = -1;
            }

        } else {
            printf("Erro: Resposta vazia.\n");
            *((int*)arg) = -1;
        }

        read_complete = true;
        return ERR_OK;

    } else {
        // Dados recebidos, acumula no buffer
        if (read_buffer_len + p->len < sizeof(read_buffer)) {
            memcpy(read_buffer + read_buffer_len, p->payload, p->len);
            read_buffer_len += p->len;
        } else {
            printf("Erro: Buffer de leitura cheio.\n");
            *((int*)arg) = -1;
            read_complete = true;
            pbuf_free(p);
            tcp_abort(tpcb); // Abortar a conexão em caso de erro
            return ERR_ABRT;
        }
        pbuf_free(p);
        return ERR_OK;
    }
}

// Callback quando a conexão TCP é estabelecida (leitura)
static err_t http_connected_read_callback(void *arg, struct tcp_pcb *tpcb, err_t err) {
    if (err != ERR_OK) {
        printf("Erro na conexão TCP (leitura)\n");
        return err;
    }

    char request[256];
    snprintf(request, sizeof(request),
             "GET /channels/%s/feeds.json?api_key=%s&results=1 HTTP/1.1\r\n"  // JSON endpoint
             "Host: %s\r\n"
             "Connection: close\r\n"
             "\r\n", CHANNEL_ID, API_KEY_READ, THINGSPEAK_HOST);

    read_buffer_len = 0;
    memset(read_buffer, 0, sizeof(read_buffer));

    tcp_write(tpcb, request, strlen(request), TCP_WRITE_FLAG_COPY);
    tcp_output(tpcb);
    tcp_recv(tpcb, http_recv_read_callback);

    return ERR_OK;
}

// Resolver DNS READ e conectar ao servidor
static void dns_read_callback(const char *name, const ip_addr_t *ipaddr, void *callback_arg) {
    if (ipaddr) {
        server_ip = *ipaddr;
        printf("Endereço IP do ThingSpeak: %s\n", ipaddr_ntoa(ipaddr));

        if (tcp_client_pcb != NULL) {  // Close existing connection if any
            tcp_close(tcp_client_pcb);
        }
        tcp_client_pcb = tcp_new();
        tcp_connect(tcp_client_pcb, &server_ip, THINGSPEAK_PORT, http_connected_read_callback);

        // CRITICAL: Set the arg for the connected callback
         tcp_arg(tcp_client_pcb, callback_arg);

    } else {
        printf("Falha na resolução de DNS\n");
        read_complete = true; // Signal error
    }
}

// Função pra receber o recorde da api
bool read_record_from_thingspeak(int *value) {
    read_complete = false; // Reset the flag
    dns_gethostbyname(THINGSPEAK_HOST, &server_ip, dns_read_callback, (void*)value);
    return true;
}