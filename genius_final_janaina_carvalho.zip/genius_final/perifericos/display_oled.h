#ifndef DISPLAY_OLED_H
#define DISPLAY_OLED_H

#include "pico/stdlib.h"
#include "inc/ssd1306.h"
#include <string.h>

// Display OLED (SSD1306)
#define OLED_I2C_PORT i2c1
#define OLED_SDA_PIN 14
#define OLED_SCL_PIN 15

extern struct render_area frame_area; // Declaração extern
extern uint8_t ssd[];

void oled_init();
void oled_clear();
void oled_show_message(const char* message);
void oled_inicial_message(); // mensagem inicial do jogo
void oled_show_level(int level); //Exibe o nível atual
void oled_show_game_over(int level); //Exibe a mensagem de Game Over
void oled_show_win(int level); //Exibe mensagem de vitória


#endif 