#ifndef MATRIZ_DE_LEDS_H
#define MATRIZ_DE_LEDS_H

#include "pico/stdlib.h"
#include "hardware/pio.h"
#include "hardware/clocks.h"

// Matriz de LEDs
#define LED_COUNT 25
#define LED_PIN 7

void npInit();
void zera_matriz();
void desenha_seta_up();
void desenha_seta_down();
void desenha_seta_right();
void desenha_seta_left();
void matriz_win();
void matriz_over();

#endif