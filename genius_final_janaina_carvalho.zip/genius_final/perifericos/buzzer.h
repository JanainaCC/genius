#ifndef BUZZER_H
#define BUZZER_H

#include "pico/stdlib.h"
#include "hardware/pwm.h" //Para usar o PWM
#include "hardware/clocks.h" //Para usar o TEMPORIZADOR
#include "pico/rand.h"

// Pino Buzzer
#define BUZZER_PIN 21

// Notas musicais (frequências em Hz)
#define NOTE_C4 262
#define NOTE_D4 294
#define NOTE_E4 330
#define NOTE_F4 349
#define NOTE_G4 392
#define NOTE_A4 440
#define NOTE_B4 494

//Tempo das notas (em milissegundos)
#define NOTE_DURATION 500

void pwm_init_buzzer();
void buzzer_play_tone(uint frequency, uint duration_ms);
void buzzer_stop();
void play_win();
void play_game_over();
void play_up();
void play_down();
void play_right();
void play_left();

#endif