#include "joystick.h"

void joystick_init() {

    // Inicialização do ADC para os eixos X e Y
    adc_init();
    adc_gpio_init(JOYSTICK_X_PIN);
    adc_gpio_init(JOYSTICK_Y_PIN);

    //Inicializa o pino do botão
    gpio_init(JOYSTICK_SW_PIN);
    gpio_set_dir(JOYSTICK_SW_PIN, GPIO_IN); //Define o pino como entrada
    gpio_pull_up(JOYSTICK_SW_PIN); //Habilita o resistor de pull-up interno

}

JoystickDirection joystick_read() {

    //Debounce (espera um pouco para evitar leituras erradas)
    static uint32_t last_read_time = 0;
    if(to_ms_since_boot(get_absolute_time()) - last_read_time < DEBOUNCE_DELAY)
    {
        return JOY_NONE; //Muito cedo para ler de novo
    }

    // Lê os valores analógicos dos eixos X e Y
    adc_select_input(ADC_CHANNEL_1); //Seleciona o canal ADC1 (eixo X)
    uint16_t x_value = adc_read();

    adc_select_input(ADC_CHANNEL_0);  // Seleciona o canal ADC0 (eixo Y)
    uint16_t y_value = adc_read();

    JoystickDirection direction = JOY_NONE;

    // Determina a direção com base nos valores lidos (exemplo)
    if (y_value > (4095 - JOYSTICK_THRESHOLD)) {
        direction = JOY_UP;
    } else if (y_value < JOYSTICK_THRESHOLD) {
        direction = JOY_DOWN;
    } else if (x_value > (4095 - JOYSTICK_THRESHOLD)) {
        direction = JOY_RIGHT;
    } else if (x_value < JOYSTICK_THRESHOLD) {
        direction = JOY_LEFT;
    } else if (!gpio_get(JOYSTICK_SW_PIN)) { //Botão pressionado
        direction = JOY_CENTER;
    }

    last_read_time = to_ms_since_boot(get_absolute_time()); //Atualiza o tempo da última leitura

    return direction;
}