#ifndef WIFI_H
#define WIFI_H

#include "pico/stdlib.h"
#include "pico/cyw43_arch.h"
#include "lwip/pbuf.h"
#include "lwip/tcp.h"
#include "lwip/dns.h"
#include "lwip/init.h"

// Defines
#define WIFI_SSID "rede"
#define WIFI_PASS "senhasenha"
#define THINGSPEAK_HOST "api.thingspeak.com"
#define THINGSPEAK_PORT 80
#define API_KEY "ESRMFPU99XXA1I4B"
#define API_KEY_READ "KTTOOSYNJXPOP3O3"
#define CHANNEL_ID "2841532"

// Variáveis Externas
extern struct tcp_pcb *tcp_client_pcb;
extern ip_addr_t server_ip;

//extern bool record_read;
extern bool read_complete;
extern bool write_complete;

// Função para inicializar e conectar ao Wi-Fi
int wifi_init(uint flag_wifi);

// Função para enviar novo recorde ao ThingSpeak
bool send_new_record_to_thingspeak();

// Protótipo da função pra receber o recorde da api
bool read_record_from_thingspeak(int *value);


#endif
