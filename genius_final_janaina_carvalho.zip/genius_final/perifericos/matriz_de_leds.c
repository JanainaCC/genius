#include "matriz_de_leds.h"
#include "ws2812b.pio.h"    

// Definição de pixel GRB
struct pixel_t {
  uint8_t G, R, B; // Três valores de 8-bits compõem um pixel.
};
typedef struct pixel_t pixel_t;
typedef pixel_t npLED_t; // Mudança de nome de "struct pixel_t" para "npLED_t" por clareza.

// Declaração do buffer de pixels que formam a matriz.
npLED_t leds[LED_COUNT];

// Variáveis para uso da máquina PIO.
PIO np_pio;
uint sm;

/**
 * Inicializa a máquina PIO para controle da matriz de LEDs.
 */
void npInit() {

  // Cria programa PIO.
  uint offset = pio_add_program(pio0, &ws2818b_program);
  np_pio = pio0;

  // Toma posse de uma máquina PIO.
  sm = pio_claim_unused_sm(np_pio, false);
  if (sm < 0) {
    np_pio = pio1;
    sm = pio_claim_unused_sm(np_pio, true); // Se nenhuma máquina estiver livre, panic!
  }

  // Inicia programa na máquina PIO obtida.
  ws2818b_program_init(np_pio, sm, offset, LED_PIN, 800000.f);

  // Limpa buffer de pixels.
  for (uint i = 0; i < LED_COUNT; ++i) {
    leds[i].R = 0;
    leds[i].G = 0;
    leds[i].B = 0;
  }

  npClear();
}

/**
 * Atribui uma cor RGB a um LED.
 */
void npSetLED(const uint index, const uint8_t r, const uint8_t g, const uint8_t b) {
  leds[index].R = r;
  leds[index].G = g;
  leds[index].B = b;
}

/**
 * Limpa o buffer de pixels.
 */
void npClear() {
  for (uint i = 0; i < LED_COUNT; ++i)
    npSetLED(i, 0, 0, 0);
}

/**
 * Escreve os dados do buffer nos LEDs.
 */
void npWrite() {
  // Escreve cada dado de 8-bits dos pixels em sequência no buffer da máquina PIO.
  for (uint i = 0; i < LED_COUNT; ++i) {
    pio_sm_put_blocking(np_pio, sm, leds[i].G);
    pio_sm_put_blocking(np_pio, sm, leds[i].R);
    pio_sm_put_blocking(np_pio, sm, leds[i].B);
  }
  sleep_us(100); // Espera 100us, sinal de RESET do datasheet.
}


// PADRÕES

void zera_matriz(){
    npClear();
    npWrite();
}

void matriz_win(){
    npSetLED(16,0,0,20);
    npSetLED(18,0,0,20);    
    npSetLED(5,0,0,20);   
    npSetLED(9,0,0,20); 
    npSetLED(3,0,0,20);
    npSetLED(2,0,0,20);    
    npSetLED(1,0,0,20);  
    npWrite();
    sleep_ms(1000);
    npSetLED(18,0,0,0);  
    npWrite();
    sleep_ms(300);
    npSetLED(16,0,0,20);
    npSetLED(18,0,0,20);    
    npSetLED(5,0,0,20);   
    npSetLED(9,0,0,20); 
    npSetLED(3,0,0,20);
    npSetLED(2,0,0,20);    
    npSetLED(1,0,0,20);  
    npWrite();
}

void matriz_over(){
  npSetLED(16,0,0,20);
  npSetLED(18,0,0,20);    
  npSetLED(6,0,0,20);   
  npSetLED(7,0,0,20); 
  npSetLED(8,0,0,20);
  npSetLED(4,0,0,20);    
  npSetLED(0,0,0,20);  
  npWrite();
  sleep_ms(1000);
  npSetLED(18,0,0,0);  
  npSetLED(16,0,0,0);  
  npWrite();
  sleep_ms(300);
  npSetLED(16,0,0,20);
  npSetLED(18,0,0,20);    
  npSetLED(6,0,0,20);   
  npSetLED(7,0,0,20); 
  npSetLED(8,0,0,20);
  npSetLED(4,0,0,20);    
  npSetLED(0,0,0,20);  
  npWrite();
}

void desenha_seta_up(){
    npClear();
    for (uint i = 2; i < LED_COUNT; i+=5){
        npSetLED(i,20,0,0);
    }
    for (uint i = 10; i < LED_COUNT-4; i+=4){
        npSetLED(i,20,0,0);
    }
    npSetLED(16,20,0,0);    
    npWrite();
}

void desenha_seta_down(){
    npClear();
    for (uint i = 2; i < LED_COUNT; i+=5){
        npSetLED(i,20,20,0);
    }
    for (uint i = 6; i < LED_COUNT/2; i+=2){
        npSetLED(i,20,20,0);
    }
    npSetLED(14,20,20,0);
    npWrite();    
}

void desenha_seta_right(){
    npClear();
    for (uint i = 10; i < LED_COUNT-10; i++){
        npSetLED(i,0,20,0);
    }
    npSetLED(2,0,20,0);
    npSetLED(8,0,20,0);    
    npSetLED(18,0,20,0);   
    npSetLED(22,0,20,0); 
    npWrite();
}

void desenha_seta_left(){
    npClear();
    for (uint i = 10; i < LED_COUNT-10; i++){
        npSetLED(i,0,0,20);
    }
    npSetLED(2,0,0,20);
    npSetLED(6,0,0,20);    
    npSetLED(16,0,0,20);   
    npSetLED(22,0,0,20); 
    npWrite();
}
