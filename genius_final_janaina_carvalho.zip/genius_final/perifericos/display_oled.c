#include "display_oled.h"
#include <stdio.h>

struct render_area frame_area;
uint8_t ssd[ssd1306_buffer_length];

void oled_init() {

    // Inicialização do i2c
    i2c_init(OLED_I2C_PORT, ssd1306_i2c_clock * 1000);
    gpio_set_function(OLED_SDA_PIN, GPIO_FUNC_I2C);
    gpio_set_function(OLED_SCL_PIN, GPIO_FUNC_I2C);
    gpio_pull_up(OLED_SDA_PIN);
    gpio_pull_up(OLED_SCL_PIN);
    
    // Processo de inicialização completo do OLED SSD1306
    ssd1306_init();
    
    // Preparar área de renderização para o display (ssd1306_width pixels por ssd1306_n_pages páginas)
    frame_area.start_column = 0;
    frame_area.end_column = ssd1306_width - 1;
    frame_area.start_page = 0;
    frame_area.end_page = ssd1306_n_pages - 1;
    
    calculate_render_area_buffer_length(&frame_area);
    
    // zera o display inteiro
    memset(ssd, 0, ssd1306_buffer_length);

    render_on_display(ssd, &frame_area);

}

void oled_clear(){
    memset(ssd, 0, ssd1306_buffer_length);
    render_on_display(ssd, &frame_area);
}

void oled_show_message(const char* message){ 
    memset(ssd, 0, ssd1306_buffer_length);
    ssd1306_draw_string(ssd, 0, 0, (char*)message);
    render_on_display(ssd, &frame_area);
}

void oled_inicial_message(){
    ssd1306_draw_string(ssd, 40, 30, "Press joystick");
    render_on_display(ssd, &frame_area);
}

void oled_show_level(int level) {
    char level_str[20];
    snprintf(level_str, sizeof(level_str), "Level: %d", level);
    ssd1306_draw_string(ssd, 0, 10, level_str); //Coluna 0, linha 10
    render_on_display(ssd, &frame_area);
}

void oled_show_game_over(int level) {
    oled_clear(); //Limpa antes
    ssd1306_draw_string(ssd, 30, 15, "Game Over");
    char level_str[20];
    ssd1306_draw_string(ssd, 20, 30, "Sequencia Max:");
    snprintf(level_str, sizeof(level_str), "%d", level-1);
    ssd1306_draw_string(ssd, 60, 45, level_str);
    render_on_display(ssd, &frame_area);
}

void oled_show_win(int level) {
    oled_clear(); //Limpa
    ssd1306_draw_string(ssd, 15, 20, "You Win");
    char level_str[20];
    snprintf(level_str, sizeof(level_str), "Level: %d", level);
    ssd1306_draw_string(ssd, 28, 30, level_str);
    render_on_display(ssd, &frame_area);
}