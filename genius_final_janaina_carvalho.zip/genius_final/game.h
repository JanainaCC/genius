#ifndef GAME_H
#define GAME_H

#include "perifericos/buzzer.h"
#include "perifericos/joystick.h"
#include "perifericos/display_oled.h"
#include "perifericos/matriz_de_leds.h"
#include "perifericos/wifi.h"
#include "pico/rand.h"

// Configurações do jogo
#define MAX_SEQUENCE_LENGTH 100 
#define INITIAL_SEQUENCE_LENGTH 1
extern int MAX_LEVEL;

extern int record_api;
extern int new_record;

extern void increment(); //TESTE API

// Definições dos estados do jogo
typedef enum {
    GAME_STATE_START, // inicializa configurações do jogo
    GAME_STATE_WAIT_FOR_START, // Aguarda o jogador pressionar o botão para iniciar
    GAME_STATE_INIT, 
    GAME_STATE_SHOW_SEQUENCE,
    GAME_STATE_PLAYER_TURN,
    GAME_STATE_GAME_OVER,
    GAME_STATE_WIN
} GameState;

// Estrutura para armazenar os dados do jogo
typedef struct {
    GameState current_state;
    int level;
    int sequence[MAX_SEQUENCE_LENGTH]; // Sequência gerada pelo jogo
    int sequence_length;
    int player_sequence_index; // Índice da sequência que o jogador está inserindo
} GameData;


void game_init();
void game_loop();

#endif