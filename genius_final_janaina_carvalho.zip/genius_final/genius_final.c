#include <stdio.h>
#include "pico/stdlib.h"
#include "game.h"
#include "perifericos/buzzer.h"
#include "perifericos/joystick.h"
#include "perifericos/display_oled.h"
#include "perifericos/matriz_de_leds.h"
#include "perifericos/wifi.h"

int flag_wifi = 0;

void setup(){

    stdio_init_all();
    pwm_init_buzzer();
    joystick_init();
    oled_init();
    npInit();
    sleep_ms(15000);
    // Inicializa o Wi-Fi uma única vez
    printf("Inicializando Wi-Fi...\n"); // Depuração
    wifi_init(flag_wifi);
    flag_wifi = 1; // Marca que o Wi-Fi está pronto para uso
    printf("Foi...\n"); // Depuração
}

int main(){
    setup();
    while (true) {
        game_loop(); // Executa o loop do jogo
    }
    return 0;
}