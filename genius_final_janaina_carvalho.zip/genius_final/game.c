#include "game.h"
#include <stdlib.h>

GameData game_data;

int new_record;
int record_api;
int MAX_LEVEL;

void increment(){
    new_record=record_api+1;
}
//ler recorde da api
bool ler_dados() {
    while (!read_record_from_thingspeak(&record_api)) {
        if (record_api != 0) {
            printf("Valor lido da API: %d\n", record_api);
            return true; // Retorna true se o valor for válido
        } else {
            printf("Valor inválido lido da API (0). Tentando novamente...\n");
        }
        sleep_ms(5000); // Espera 5 segundos antes de tentar novamente
    }
}
// enviar recorde para api
void enviar_dados(){
    printf("Jogador venceu! Enviando novo recorde para a API...\n");
    send_new_record_to_thingspeak();
    int timeout = 60; // 60 segundos de timeout  
    while (!write_complete && timeout > 0) {
        sleep_ms(1000);
        printf(".");
        timeout--;
        if (timeout <= 40) {
            printf("Escrita da API não funcionou. Tentando novamente... \n");
            send_new_record_to_thingspeak();
            sleep_ms(15000);
            if (write_complete) {
                printf("\nEscrita confirmada!\n");
                write_complete = false;
            }
        }
    }
    if (write_complete) {
        printf("\nEscrita confirmada!\n");
        write_complete = false;
    } else {
        printf("\nErro: Timeout ao aguardar escrita. REINICIE A PLACA\n");
        write_complete = false;
    }
}

// Inicializa o jogo
void game_init() {

    // Lê o recorde da API até obter um valor válido
    if (ler_dados()) {
        read_complete = true;
    }

    // Aguarda a leitura inicial da API ser concluída
    while (!read_complete) {
        sleep_ms(1000); // Espera até que a leitura da API seja concluída
    }
    
    // Define o MAX_LEVEL com base no record_api
    MAX_LEVEL = record_api + 1;

    // Verifica se o MAX_LEVEL não excede o tamanho máximo da sequência
    if (MAX_LEVEL > MAX_SEQUENCE_LENGTH) {
        printf("Erro: MAX_LEVEL excede o tamanho máximo da sequência.\n");
        MAX_LEVEL = MAX_SEQUENCE_LENGTH;
    }

    game_data.current_state = GAME_STATE_WAIT_FOR_START; // Inicialmente, espera pelo botão
    game_data.level = 1;
    game_data.sequence_length = INITIAL_SEQUENCE_LENGTH;
    game_data.player_sequence_index = 0;

    // Limpa a sequência
    for (int i = 0; i < MAX_SEQUENCE_LENGTH; i++) {
        game_data.sequence[i] = 0;
    }

    oled_inicial_message(); // Exibe a mensagem inicial
    zera_matriz();
}


// Função para exibir uma única cor/direção na matriz de LEDs e tocar o som
void show_direction(int direction) {
    switch (direction) {
        case 0: // UP
            desenha_seta_up();
            play_up();
            break;
        case 1: // DOWN
            desenha_seta_down();
            play_down();
            break;
        case 2: // RIGHT
            desenha_seta_right();
            play_right();
            break;
        case 3: // LEFT
            desenha_seta_left();
            play_left();
            break;
    }
    zera_matriz();
    sleep_ms(250);
}


// Função para exibir a sequência na matriz de LEDs e tocar os sons
void show_sequence() {
    for (int i = 0; i < game_data.sequence_length; i++) {
        show_direction(game_data.sequence[i]);
    }
}


// Função para aguardar e processar a entrada do jogador
void player_turn() {
    JoystickDirection direction = joystick_read();

    if (direction != JOY_NONE && direction != JOY_CENTER) {
        int player_move;

        switch (direction) {
            case JOY_UP:
                player_move = 0;
                break;
            case JOY_DOWN:
                player_move = 1;
                break;
            case JOY_RIGHT:
                player_move = 2;
                break;
            case JOY_LEFT:
                player_move = 3;
                break;
            default:
                return; // Ignora outras direções
        }

        // Mostra a direção que o jogador escolheu e toca o som
        show_direction(player_move);

        // Verifica se o movimento do jogador corresponde à sequência
        if (player_move == game_data.sequence[game_data.player_sequence_index]) {
            game_data.player_sequence_index++;

            // Se o jogador completou a sequência, passa para o próximo nível
            if (game_data.player_sequence_index == game_data.sequence_length) {
                if (game_data.level == MAX_LEVEL) {
                    game_data.current_state = GAME_STATE_WIN;
                } else {
                    // Adiciona um novo elemento à sequência
                    game_data.sequence[game_data.sequence_length] = get_rand_32() % 4; // 0: UP, 1: DOWN, 2: RIGHT, 3: LEFT
                    game_data.sequence_length++;
                    game_data.level++;
                    game_data.player_sequence_index = 0; // Reinicia o índice do jogador
                    game_data.current_state = GAME_STATE_SHOW_SEQUENCE; // Volta para mostrar a sequência completa
                    sleep_ms(500);
                }
                return; //Retorna para o game_loop após completar a sequência
            }
        } else {
            // Se o jogador errou a sequência, game over
            game_data.current_state = GAME_STATE_GAME_OVER;
            return; // Retorna para o game_loop após errar a sequência

        }
    }
}

// Função principal do loop do jogo
void game_loop() {
    switch (game_data.current_state) {
        case GAME_STATE_START:
            game_init();
        break;
        case GAME_STATE_WAIT_FOR_START:
            game_init();
            // Aguarda o botão do joystick ser pressionado
            if (joystick_read() == JOY_CENTER) {
                // Gera o primeiro elemento da sequência
                game_data.sequence[0] = get_rand_32() % 4; // 0: UP, 1: DOWN, 2: RIGHT, 3: LEFT
                game_data.current_state = GAME_STATE_INIT;
                sleep_ms(200);
            }
            break;

        case GAME_STATE_INIT:
            // Mostra a mensagem inicial e vai para o próximo estado
            oled_show_message("Prepare-se...");
            sleep_ms(2000);
            oled_clear();
            game_data.current_state = GAME_STATE_SHOW_SEQUENCE;
            break;

        case GAME_STATE_SHOW_SEQUENCE:
            // Exibe a sequência para o jogador
            oled_show_level(game_data.level);
            show_sequence();
            game_data.player_sequence_index = 0;
            game_data.current_state = GAME_STATE_PLAYER_TURN;
            break;

        case GAME_STATE_PLAYER_TURN:
            // Aguarda a entrada do jogador
            player_turn();
            break;

        case GAME_STATE_GAME_OVER:
            // Exibe a tela de game over
            oled_show_game_over(game_data.level);
            play_game_over();
            matriz_over();
            sleep_ms(5000); // Espera por 5 segundos antes de reiniciar
            oled_clear();
            game_data.current_state = GAME_STATE_START;
            break;

        case GAME_STATE_WIN:
            // Exibe a tela de vitória
            oled_show_win(game_data.level);
            play_win();
            matriz_win();
            new_record = MAX_LEVEL;
            enviar_dados();
            sleep_ms(5000);
            oled_clear();
            game_data.current_state = GAME_STATE_START;
            break;
    }
}